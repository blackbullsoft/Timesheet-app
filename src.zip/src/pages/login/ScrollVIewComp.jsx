import {StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {ScrollView} from 'react-native-gesture-handler';

const ScrollVIewComp = () => {
  return (
    <View>
      <ScrollView horizontal>
        <Text>Rohan</Text>
        <Text>Mognj</Text>
        <Text>VIjijds</Text>
        <Text>02i9</Text>
        <Text>nj;bh3</Text>
        <Text>njnjk34</Text>
        <Text>dsdnsjnjs</Text>
        <Text>njnjnjdnje</Text>
        <Text>dsdnsjnjs</Text>
        <Text>dsdnsjnjs</Text>
        <Text>dsdnsjnjs</Text>
        <Text>dsdnsjnjs</Text>
        <Text>dsdnsjnjs</Text>
      </ScrollView>
    </View>
  );
};

export default ScrollVIewComp;

const styles = StyleSheet.create({});
