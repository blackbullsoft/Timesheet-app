const API_BASE_URL = 'http://174.138.57.202:8000'; 

export default API_BASE_URL;